
/**
 * Clase encargada de representar a Coppel, extendiendo a banco.
 */
public class Coppel extends Banco{

    public Coppel(){
        setBancosInterface(new CoppelInterface());
    }

}
