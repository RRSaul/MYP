/**
 * Clase pública encargada de representar la pizza meat lovers.
 */
public class PizzaMeatLovers extends Pizza {
    /**
     * Constructor público de PizzaMeatLovers.
     */
    public PizzaMeatLovers(){
        setNombre("Pizza Meat Lovers");
        setMasa("gruesa");
        setQueso("manchego");
        setCarne( "jamón y salchica");
        setPrecio(109.99);
    }
}
